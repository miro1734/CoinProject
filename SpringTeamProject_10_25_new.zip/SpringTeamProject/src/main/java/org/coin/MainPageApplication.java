package org.coin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainPageApplication.class, args);
	}

}
